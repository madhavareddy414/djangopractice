from django.apps import AppConfig


class StudentrestappConfig(AppConfig):
    name = 'studentrestapp'
