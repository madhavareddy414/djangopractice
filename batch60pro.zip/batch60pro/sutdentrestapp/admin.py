from django.contrib import admin

# Register your models here.
from sutdentrestapp.models import Student

admin.site.register(Student)
