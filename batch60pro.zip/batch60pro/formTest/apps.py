from django.apps import AppConfig


class FormtestConfig(AppConfig):
    name = 'formTest'
