from django.apps import AppConfig


class MixinclaConfig(AppConfig):
    name = 'mixincla'
