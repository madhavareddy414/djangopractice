from django.contrib import admin
from modelApp.models import Employee,EmpSalary

# Register your models here.
admin.site.register(Employee)
admin.site.register(EmpSalary)
