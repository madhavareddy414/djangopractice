from django.apps import AppConfig


class ApvappConfig(AppConfig):
    name = 'apvapp'
